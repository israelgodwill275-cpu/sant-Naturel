SANTÉ PAR LE NATUREL

Ouvrir index.html dans un navigateur.

Fichiers :
- index.html
- style.css
- script.js
- fondatrice.png

Le site est responsive et ne nécessite aucun framework.
Pour changer l'e-mail, modifier contact@santeparlenaturel.com dans index.html.
